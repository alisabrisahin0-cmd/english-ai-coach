import { NextResponse } from "next/server";

export async function POST() {
  return NextResponse.json({
    ok: true,
    feedback: {
      fluency: 72,
      grammar: 66,
      pronunciation: 70,
      note: "Demo feedback: Daha kısa cümlelerle başlayıp linking çalış.",
    },
  });
}
