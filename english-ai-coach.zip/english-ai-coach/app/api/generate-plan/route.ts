import { NextResponse } from "next/server";

export async function POST() {
  return NextResponse.json({
    ok: true,
    plan: {
      title: "Demo AI Plan",
      focus: ["Grammar", "Speaking", "Pronunciation"],
    },
  });
}
