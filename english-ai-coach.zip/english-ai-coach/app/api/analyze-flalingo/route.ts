import { NextResponse } from "next/server";

export async function POST() {
  return NextResponse.json({
    ok: true,
    summary: "Demo PDF analizi tamamlandı.",
    weakAreas: ["Past Simple", "Prepositions", "Pronunciation"],
  });
}
