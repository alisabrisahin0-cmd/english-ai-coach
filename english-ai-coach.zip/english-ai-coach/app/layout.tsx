import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "English AI Coach",
  description: "Flalingo + NotebookLM + AI Speaking kişisel İngilizce koçu",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="tr">
      <body>{children}</body>
    </html>
  );
}
