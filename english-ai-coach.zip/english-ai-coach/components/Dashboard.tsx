"use client";

import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  BarChart3,
  BookOpen,
  Brain,
  CheckCircle2,
  Download,
  FileText,
  Flame,
  Headphones,
  Mic,
  Pause,
  Play,
  RefreshCcw,
  Sparkles,
  Target,
  Trophy,
  Upload,
  Video,
  Zap,
} from "lucide-react";

const demoProgram = {
  profile: {
    name: "Ali",
    level: "A2 → B1",
    goal: "Speaking + Work English",
    dailyMinutes: 45,
    weakAreas: ["Past Simple", "Present Simple", "Prepositions", "Pronunciation / Linking"],
  },
  aiSummary:
    "Flalingo raporlarına göre ana problem kelime bilmekten çok doğru cümle kurma, zaman seçimi ve konuşurken doğal bağlama. Bu hafta grammar + speaking ağırlıklı ilerler.",
  dailyPlan: [
    {
      name: "Warm-up Vocabulary",
      time: "7 dk",
      xp: 35,
      task: "Export, shipment, fabric, warehouse, versatile kelimeleriyle 5 cümle kur.",
      area: "Vocabulary",
    },
    {
      name: "Grammar Repair",
      time: "15 dk",
      xp: 80,
      task: "Present Simple vs Past Simple: I work / I worked / I studied / I haven't watched it yet.",
      area: "Grammar",
    },
    {
      name: "Speaking Sprint",
      time: "10 dk",
      xp: 90,
      task: "İşini 60 saniyede anlat: I work in foreign trade. We export fabrics to Europe.",
      area: "Speaking",
    },
    {
      name: "Pronunciation / Linking",
      time: "8 dk",
      xp: 65,
      task: "Is he / Is she, listen to, work in, export to kalıplarını sesli tekrar et.",
      area: "Pronunciation",
    },
    {
      name: "NotebookLM Review",
      time: "5 dk",
      xp: 40,
      task: "Bugünkü hataları NotebookLM kaynak notuna ekle ve 3 test sorusu üret.",
      area: "Review",
    },
  ],
  quiz: [
    {
      question: "Rutin işinden bahsederken hangisi daha doğru?",
      options: ["I am working in a factory.", "I work in a factory.", "I worked in a factory every day."],
      answer: "I work in a factory.",
      xp: 25,
    },
    {
      question: "Boşluğu doldur: I listened ___ Six Minute English today.",
      options: ["to", "in", "on"],
      answer: "to",
      xp: 25,
    },
    {
      question: "Doğru cümleyi seç.",
      options: ["I live on Istanbul.", "I live in Istanbul.", "I am live in Istanbul."],
      answer: "I live in Istanbul.",
      xp: 25,
    },
  ],
  weeklyFocus: [
    "3 gün: Present Simple / Past Simple düzeltme",
    "2 gün: AI speaking session + pronunciation feedback",
    "1 gün: NotebookLM kaynaklarından quiz çözümü",
    "1 gün: Haftalık rapor, eksik kapatma ve yeni plan üretimi",
  ],
};

const initialWeeklyLog = [
  { day: "Pazartesi", done: ["Warm-up Vocabulary", "Grammar Repair"], missed: ["Speaking Sprint"] },
  { day: "Salı", done: ["Speaking Sprint", "Pronunciation / Linking"], missed: [] },
  { day: "Çarşamba", done: [], missed: ["Grammar Repair", "NotebookLM Review"] },
  { day: "Perşembe", done: ["Warm-up Vocabulary"], missed: ["Speaking Sprint"] },
  { day: "Cuma", done: [], missed: [] },
  { day: "Cumartesi", done: [], missed: [] },
  { day: "Pazar", done: [], missed: [] },
];

const speakingPrompts = [
  "Tell me about your job in foreign trade.",
  "Explain the difference between import and export.",
  "Talk about your last English lesson using Past Simple.",
  "Describe Adana using comparatives: hotter, more crowded, better.",
];

function formatTime(seconds: number) {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, "0");
  const secs = (seconds % 60).toString().padStart(2, "0");
  return `${minutes}:${secs}`;
}

export default function Dashboard() {
  const [program, setProgram] = useState(demoProgram);
  const [xp, setXp] = useState(860);
  const [streak, setStreak] = useState(6);
  const [completed, setCompleted] = useState([true, true, false, false, false]);
  const [weeklyLog, setWeeklyLog] = useState(initialWeeklyLog);
  const [timer, setTimer] = useState(10 * 60);
  const [timerActive, setTimerActive] = useState(false);
  const [speakingActive, setSpeakingActive] = useState(false);
  const [speakingPromptIndex, setSpeakingPromptIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, string>>({});
  const [uploadedFiles, setUploadedFiles] = useState(["Flalingo Report - December.pdf"]);
  const [showToast, setShowToast] = useState(false);

  const completedCount = completed.filter(Boolean).length;
  const progress = Math.round((completedCount / program.dailyPlan.length) * 100);
  const level = Math.floor(xp / 500) + 1;
  const levelProgress = Math.round(((xp % 500) / 500) * 100);
  const speakingPrompt = speakingPrompts[speakingPromptIndex % speakingPrompts.length];

  useEffect(() => {
    if (!timerActive) return;

    const interval = window.setInterval(() => {
      setTimer((prev) => {
        if (prev <= 1) {
          window.clearInterval(interval);
          setTimerActive(false);
          setXp((old) => old + 40);
          setStreak((old) => old + 1);
          setShowToast(true);
          return 10 * 60;
        }
        return prev - 1;
      });
    }, 1000);

    return () => window.clearInterval(interval);
  }, [timerActive]);

  useEffect(() => {
    if (!showToast) return;
    const timeout = window.setTimeout(() => setShowToast(false), 1800);
    return () => window.clearTimeout(timeout);
  }, [showToast]);

  const toggleTask = (index: number) => {
    setCompleted((prev) => {
      const next = prev.map((value, i) => (i === index ? !value : value));
      const task = program.dailyPlan[index];

      if (!prev[index]) {
        setXp((old) => old + task.xp);
        setShowToast(true);
        setWeeklyLog((old) =>
          old.map((day, dayIndex) =>
            dayIndex === 4
              ? {
                  ...day,
                  done: [...new Set([...day.done, task.name])],
                  missed: day.missed.filter((item) => item !== task.name),
                }
              : day
          )
        );
      } else {
        setXp((old) => Math.max(0, old - task.xp));
      }

      return next;
    });
  };

  const handleUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadedFiles((old) => [file.name, ...old]);
    setProgram((old) => ({
      ...old,
      aiSummary:
        "Yeni rapor yüklendi. AI analizine göre bu hafta Past Simple, prepositions ve speaking sprint ağırlığı artırıldı.",
    }));
    setShowToast(true);
  };

  const answerQuiz = (quizIndex: number, option: string) => {
    if (selectedAnswers[quizIndex]) return;

    setSelectedAnswers((old) => ({ ...old, [quizIndex]: option }));

    if (option === program.quiz[quizIndex].answer) {
      setXp((old) => old + program.quiz[quizIndex].xp);
      setShowToast(true);
    }
  };

  const downloadNotebookFile = () => {
    const markdown = `# Flalingo AI Program

## AI Analizi
${program.aiSummary}

## Zayıf Alanlar
${program.profile.weakAreas.map((item) => `- ${item}`).join("\n")}

## Günlük Plan
${program.dailyPlan.map((item) => `- ${item.name} (${item.time}): ${item.task}`).join("\n")}

## Haftalık Odak
${program.weeklyFocus.map((item) => `- ${item}`).join("\n")}`;

    const blob = new Blob([markdown], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "notebooklm-flalingo-ai-program.md";
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <main className="min-h-screen overflow-hidden bg-slate-950 text-white">
      <div className="pointer-events-none fixed inset-0">
        <motion.div
          animate={{ x: [0, 40, 0], y: [0, 25, 0] }}
          transition={{ duration: 10, repeat: Infinity }}
          className="absolute -left-24 -top-24 h-80 w-80 rounded-full bg-cyan-500/20 blur-3xl"
        />
        <motion.div
          animate={{ x: [0, -35, 0], y: [0, 35, 0] }}
          transition={{ duration: 12, repeat: Infinity }}
          className="absolute right-0 top-32 h-96 w-96 rounded-full bg-fuchsia-500/20 blur-3xl"
        />
      </div>

      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed left-1/2 top-5 z-50 -translate-x-1/2 rounded-full border border-cyan-300/30 bg-slate-900/95 px-5 py-3 shadow-2xl shadow-cyan-500/20 backdrop-blur-xl"
          >
            <div className="flex items-center gap-2 text-sm font-bold">
              <Sparkles className="h-4 w-4 text-cyan-200" />
              Sistem güncellendi. XP ve plan yeniden işlendi.
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <section className="relative mx-auto grid max-w-7xl gap-6 px-6 py-8 lg:grid-cols-[0.95fr_1.25fr]">
        <div className="space-y-6">
          <Panel>
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-cyan-300/20 bg-cyan-300/10 px-4 py-2 text-sm text-cyan-100">
              <Brain className="h-4 w-4" />
              Flalingo + NotebookLM + AI Speaking Demo
            </div>

            <h1 className="text-4xl font-black tracking-tight md:text-6xl">Kişisel İngilizce kontrol paneli</h1>
            <p className="mt-4 text-sm leading-6 text-slate-300">
              Flalingo raporlarını, haftalık takibi, NotebookLM kaynaklarını, quizleri ve speaking oturumunu tek ekranda gösterir.
            </p>

            <div className="mt-6 grid grid-cols-3 gap-3">
              <Metric icon={Trophy} label="Level" value={level} />
              <Metric icon={Flame} label="Streak" value={`${streak} Gün`} />
              <Metric icon={Target} label="Bugün" value={`${progress}%`} />
            </div>

            <div className="mt-5 rounded-3xl border border-white/10 bg-slate-900/60 p-4">
              <div className="mb-2 flex justify-between text-sm">
                <span className="text-slate-300">XP: {xp}</span>
                <span className="font-bold text-cyan-200">Level Progress: %{levelProgress}</span>
              </div>
              <div className="h-3 overflow-hidden rounded-full bg-white/10">
                <motion.div animate={{ width: `${levelProgress}%` }} className="h-full rounded-full bg-cyan-300" />
              </div>
            </div>
          </Panel>

          <Panel>
            <h2 className="text-xl font-black">Rapor ve Kaynak Ekle</h2>
            <p className="mt-2 text-sm text-slate-400">Demo modunda dosya yüklenince AI analiz edilmiş gibi program özeti güncellenir.</p>

            <label className="mt-5 flex cursor-pointer items-center justify-center gap-3 rounded-3xl border border-dashed border-cyan-300/30 bg-cyan-300/10 p-6 text-center hover:bg-cyan-300/15">
              <Upload className="h-5 w-5 text-cyan-200" />
              <span className="font-bold">Flalingo PDF Raporu Yükle</span>
              <input type="file" accept="application/pdf" onChange={handleUpload} className="hidden" />
            </label>

            <div className="mt-4 grid gap-3 md:grid-cols-2">
              <ResourceButton icon={BookOpen} label="Kitap Kaynağı" />
              <ResourceButton icon={Video} label="Video Kaynağı" />
            </div>

            <div className="mt-4 space-y-2">
              {uploadedFiles.map((file) => (
                <div key={file} className="flex items-center gap-2 rounded-2xl border border-white/10 bg-slate-900/60 p-3 text-sm text-slate-300">
                  <FileText className="h-4 w-4 text-cyan-200" />
                  {file}
                </div>
              ))}
            </div>
          </Panel>

          <Panel>
            <h2 className="text-xl font-black">Zamanlı Odak Modu</h2>
            <div className="mt-4 flex flex-wrap items-center gap-4">
              <div className="rounded-3xl border border-white/10 bg-slate-900/70 px-6 py-4 text-4xl font-black">{formatTime(timer)}</div>
              <button
                onClick={() => setTimerActive((old) => !old)}
                className="inline-flex items-center rounded-2xl bg-cyan-300 px-6 py-4 font-bold text-slate-950 hover:bg-cyan-200"
              >
                {timerActive ? <Pause className="mr-2 h-4 w-4" /> : <Play className="mr-2 h-4 w-4" />}
                {timerActive ? "Duraklat" : "Başlat"}
              </button>
              <button
                onClick={() => {
                  setTimer(10 * 60);
                  setTimerActive(false);
                }}
                className="inline-flex items-center rounded-2xl border border-white/10 bg-white/5 px-6 py-4 font-bold text-white hover:bg-white/10"
              >
                <RefreshCcw className="mr-2 h-4 w-4" />
                Sıfırla
              </button>
            </div>
            <p className="mt-3 text-sm text-slate-400">Sayaç bitince +40 XP ve +1 streak verir.</p>
          </Panel>
        </div>

        <div className="space-y-6">
          <Panel>
            <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
              <div>
                <p className="text-sm uppercase tracking-[0.35em] text-cyan-200">AI Analiz</p>
                <h2 className="mt-2 text-3xl font-black">{program.profile.level} Programı</h2>
                <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-300">{program.aiSummary}</p>
              </div>
              <button onClick={downloadNotebookFile} className="inline-flex items-center rounded-2xl bg-white px-5 py-4 font-bold text-slate-950 hover:bg-slate-200">
                <Download className="mr-2 h-4 w-4" />
                NotebookLM
              </button>
            </div>

            <div className="mt-5 grid gap-3 md:grid-cols-2">
              {program.profile.weakAreas.map((area) => (
                <div key={area} className="rounded-3xl border border-white/10 bg-slate-900/60 p-4 text-sm text-slate-300">
                  <span className="mb-2 inline-flex rounded-full bg-fuchsia-300/15 px-3 py-1 text-xs font-bold text-fuchsia-100">Eksik Alan</span>
                  <p>{area}</p>
                </div>
              ))}
            </div>
          </Panel>

          <Panel>
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-xl font-black">Bugünkü Görevler</h2>
              <span className="rounded-full bg-cyan-300/15 px-3 py-1 text-sm font-bold text-cyan-100">%{progress}</span>
            </div>
            <div className="h-3 overflow-hidden rounded-full bg-white/10">
              <motion.div animate={{ width: `${progress}%` }} className="h-full rounded-full bg-cyan-300" />
            </div>

            <div className="mt-5 grid gap-3">
              {program.dailyPlan.map((task, index) => (
                <motion.div
                  key={task.name}
                  whileHover={{ scale: 1.01 }}
                  className="grid grid-cols-[auto_1fr_auto] items-center gap-4 rounded-3xl border border-white/10 bg-slate-900/60 p-4"
                >
                  <div className="rounded-2xl bg-white/10 p-3">
                    {task.area === "Speaking" ? (
                      <Mic className="h-5 w-5 text-cyan-200" />
                    ) : task.area === "Pronunciation" ? (
                      <Headphones className="h-5 w-5 text-cyan-200" />
                    ) : (
                      <Target className="h-5 w-5 text-cyan-200" />
                    )}
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-bold">{task.name}</h3>
                      <span className="rounded-full bg-white/10 px-2 py-1 text-xs text-slate-300">{task.time}</span>
                      <span className="rounded-full bg-cyan-300/15 px-2 py-1 text-xs font-bold text-cyan-100">+{task.xp} XP</span>
                    </div>
                    <p className="mt-1 text-sm text-slate-300">{task.task}</p>
                  </div>
                  <button
                    onClick={() => toggleTask(index)}
                    className={`rounded-2xl border p-3 ${
                      completed[index]
                        ? "border-emerald-300 bg-emerald-300/20 text-emerald-100"
                        : "border-white/10 bg-white/5 text-slate-400 hover:bg-white/10"
                    }`}
                  >
                    <CheckCircle2 className="h-5 w-5" />
                  </button>
                </motion.div>
              ))}
            </div>
          </Panel>

          <div className="grid gap-6 lg:grid-cols-2">
            <Panel>
              <div className="mb-4 flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-cyan-200" />
                <h2 className="text-xl font-black">Haftalık Takip</h2>
              </div>
              <div className="space-y-3">
                {weeklyLog.map((day) => (
                  <div key={day.day} className="rounded-3xl border border-white/10 bg-slate-900/60 p-4">
                    <p className="font-bold">{day.day}</p>
                    <p className="mt-2 text-xs text-emerald-200">Yapılan: {day.done.length ? day.done.join(", ") : "Henüz yok"}</p>
                    <p className="mt-1 text-xs text-rose-200">Eksik: {day.missed.length ? day.missed.join(", ") : "Yok"}</p>
                  </div>
                ))}
              </div>
            </Panel>

            <Panel>
              <div className="mb-4 flex items-center gap-2">
                <Mic className="h-5 w-5 text-fuchsia-200" />
                <h2 className="text-xl font-black">AI Speaking</h2>
              </div>
              <div className="rounded-3xl border border-white/10 bg-slate-900/60 p-4">
                <p className="text-xs uppercase tracking-[0.25em] text-fuchsia-200">Prompt</p>
                <p className="mt-2 text-sm leading-6 text-slate-200">{speakingPrompt}</p>
              </div>
              <div className="mt-4 grid gap-3">
                <button
                  onClick={() => setSpeakingActive((old) => !old)}
                  className={`inline-flex items-center justify-center rounded-2xl py-4 font-bold ${
                    speakingActive ? "bg-rose-400 text-slate-950 hover:bg-rose-300" : "bg-fuchsia-300 text-slate-950 hover:bg-fuchsia-200"
                  }`}
                >
                  <Mic className="mr-2 h-4 w-4" />
                  {speakingActive ? "Konuşmayı Durdur" : "Konuşmayı Başlat"}
                </button>
                <button
                  onClick={() => setSpeakingPromptIndex((old) => old + 1)}
                  className="rounded-2xl border border-white/10 bg-white/5 py-4 font-bold text-white hover:bg-white/10"
                >
                  Yeni Speaking Sorusu
                </button>
              </div>
              <p className="mt-3 text-xs leading-5 text-slate-400">
                Gerçek sürümde burası Grok API veya Gemini API ile transkript, telaffuz, akıcılık ve grammar feedback döndürür.
              </p>
            </Panel>
          </div>

          <Panel>
            <div className="mb-4 flex items-center gap-2">
              <Zap className="h-5 w-5 text-yellow-200" />
              <h2 className="text-xl font-black">Otomatik Quiz</h2>
            </div>
            <div className="grid gap-4">
              {program.quiz.map((quiz, quizIndex) => {
                const selected = selectedAnswers[quizIndex];
                const correct = selected === quiz.answer;

                return (
                  <div key={quiz.question} className="rounded-3xl border border-white/10 bg-slate-900/60 p-4">
                    <p className="font-bold">{quiz.question}</p>
                    <div className="mt-3 grid gap-2 md:grid-cols-3">
                      {quiz.options.map((option) => (
                        <button
                          key={option}
                          onClick={() => answerQuiz(quizIndex, option)}
                          className={`rounded-2xl border p-3 text-left text-sm transition ${
                            selected === option
                              ? correct
                                ? "border-emerald-300 bg-emerald-300/20 text-emerald-100"
                                : "border-rose-300 bg-rose-300/20 text-rose-100"
                              : "border-white/10 bg-white/5 text-slate-300 hover:bg-white/10"
                          }`}
                        >
                          {option}
                        </button>
                      ))}
                    </div>
                    {selected && (
                      <p className="mt-3 text-sm text-slate-300">
                        Doğru cevap: <span className="font-bold text-cyan-100">{quiz.answer}</span>
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </Panel>
        </div>
      </section>
    </main>
  );
}

function Panel({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-[2rem] border border-white/10 bg-white/5 p-6 text-white shadow-2xl backdrop-blur-xl">
      {children}
    </div>
  );
}

function Metric({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string | number }) {
  return (
    <motion.div whileHover={{ y: -4 }} className="rounded-3xl border border-white/10 bg-slate-900/60 p-4">
      <Icon className="mb-3 h-5 w-5 text-cyan-200" />
      <p className="text-xs text-slate-400">{label}</p>
      <p className="text-lg font-black">{value}</p>
    </motion.div>
  );
}

function ResourceButton({ icon: Icon, label }: { icon: React.ElementType; label: string }) {
  return (
    <button className="flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 p-4 text-sm font-bold text-slate-200 transition hover:bg-white/10">
      <Icon className="h-4 w-4 text-cyan-200" />
      {label}
    </button>
  );
}
